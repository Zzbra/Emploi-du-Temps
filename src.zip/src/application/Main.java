package application;

public class Main {
    public static void main(String[] args) {
        Solveur solveur = new Solveur(new Probleme(2, 3));
        solveur.definirContraintes();
        solveur.solveWithModel();
        solveur.printModele();
        solveur.printSolution();
        solveur.printDifferences();
    }

}
