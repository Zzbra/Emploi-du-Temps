package application;
public enum Jour {
	LUNDI, MARDI, MERCREDI, JEUDI, VENDREDI;
}
